# combined_calculator.py

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        return "Error! Division by zero."
    return x / y

def calculate_expression(expr):
    try:
        # Evaluate the string expression
        result = eval(expr)
        return result
    except ZeroDivisionError:
        return "Error! Division by zero."
    except Exception:
        return "Error! Invalid expression."

def main():
    print("========== CLI Calculator ==========")
    print("Options:")
    print("1. Add")
    print("2. Subtract")
    print("3. Multiply")
    print("4. Divide")
    print("5. Enter Expression as String")
    print("6. Exit")
    print("====================================")

    while True:
        choice = input("Enter choice (1-6): ")

        if choice == '6':
            print("Exiting Calculator. Goodbye!")
            break

        if choice in ['1', '2', '3', '4']:
            try:
                num1 = float(input("Enter first number: "))
                num2 = float(input("Enter second number: "))
            except ValueError:
                print("Invalid input! Please enter numeric values.\n")
                continue

            if choice == '1':
                print(f"Result: {num1} + {num2} = {add(num1, num2)}\n")
            elif choice == '2':
                print(f"Result: {num1} - {num2} = {subtract(num1, num2)}\n")
            elif choice == '3':
                print(f"Result: {num1} * {num2} = {multiply(num1, num2)}\n")
            elif choice == '4':
                print(f"Result: {num1} / {num2} = {divide(num1, num2)}\n")
        elif choice == '5':
            expr = input("Enter your expression (e.g., 5+3*2): ")
            result = calculate_expression(expr)
            print(f"Result: {result}\n")
        else:
            print("Invalid choice! Please select from 1 to 6.\n")

if __name__ == "__main__":
    main()
