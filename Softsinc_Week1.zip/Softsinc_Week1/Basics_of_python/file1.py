a = 100
b = 29
c = 56
d = 25

print("Divide First two operands!\n")
if a > b:
    print(f"A divided by B is: {a / b}")  
else:
    print(f"B divided by A is: {b / a}")  

print("Divide Next two operands!\n")
if d > c:
    print(f"D divided by C is: {d / c}")  
else:
    print(f"C divided by D is: {c / d}")  