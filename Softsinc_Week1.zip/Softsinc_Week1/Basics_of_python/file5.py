f=open("file5.txt","w+")
text="Hi Miss\nLife becomes hard as we grow older, we realise the dynamics of life\nWe often hold hopes on people who are not meant to be wth us later in life\nBut we cant help ourselves sometimes, Maybe we love them, and cant let go of them\nBut, letting go is love too right?then why do we choose to hold on?\nMaybe love varries, for some it is to let go and for others it is to stay till the end\nIn the end it is love only</3 "
f.write(text)
print(text)
f.close()