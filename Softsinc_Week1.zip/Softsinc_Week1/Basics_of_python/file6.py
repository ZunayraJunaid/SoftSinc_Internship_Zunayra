class ShoppingKart:
    item1=input("Enter item 1:")
    item2=input("Enter item 2:")
    item3=input("Enter item 3:")
    item4=input("Enter item 4:")

    def DisplayKart(self):
        print( sk.item1)
        print(sk.item2)
        print(sk.item3)
        print(sk.item4)

sk=ShoppingKart() 
sk.DisplayKart()     
