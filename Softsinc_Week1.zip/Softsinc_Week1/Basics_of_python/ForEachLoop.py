number=[23,45,22,14,56,86]

#each iteration prints the value in list
for num in number:
    print(num)

