#for loops

#double increment (step)
print("PRINT ALL EVEN NUMBERS TILL 20:\n")
for i in range(0,20,2):
    print(i)

#sum of range
sum=0

print("THE PRINT SUM OF NUMBERS TILL 50:\n")
for i in range(1,50):
    sum+=i

print(f"Sum={sum}") 

#factorial of numbers 
num=int(input("Enter the number:"))
f=1
for i in range(1,num+1):
    f*=i

print(f"THE FACTORIAL OF THE GIVEN NUMBER IS:{f}")   

#string elements count
Str="Hello World!"
count=0
for i in Str:
    count+=1
print (f"{count}")    