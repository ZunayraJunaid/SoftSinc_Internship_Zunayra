class Person:
    
    def __init__(self,name="",age="",gender="",location=""):
        self.name=name
        self.age=age
        self.gender=gender
        self.location=location
    
    def getData(self):
      self.name=input("Enter name: ")
      self.age=input("Enter age: ")
      self.gender=input("Enter gender: ")
      self.location=input("Enter location: ")

    def Display(self):
        print(self.name)
        print(self.age)
        print(self.gender)
        print(self.location)

    def savetofile(self):    
      f=open("file6.txt","a+")  
      f.write(f"\nName: {self.name}\nAge: {self.age}\nGender: {self.gender}\nLocation: {self.location}") 
      f.close() 
 
p=Person()
p.getData()  
p.Display()
p.savetofile()   
              
