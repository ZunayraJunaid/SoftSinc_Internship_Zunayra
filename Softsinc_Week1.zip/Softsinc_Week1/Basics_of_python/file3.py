# #even odd check
def EvenOdd(a,b):
    if(a%2==0):
        print("a is even")
    else:
        print("a is odd")

    if(b%2==0):
        print("b is even") 

    else:
        print("b is odd")      

num1=int(input("Enter number 1: "))        
num2=int(input("Enter number 2: ")) 

EvenOdd(num1,num2)

#factorial 
def factorial(n):
  f=1
  for i in range(1,n+1):
      f*=i
      
  return f  

num=int(input("Enter number: "))  
factorial(num) 
print(f"Factorial of {num} is :{factorial(num)}")