class Person:
    def __init__(self,name="",id=""):
        self.name=name
        self.id=id

    def PrintData(self):
       self.name= input('enter name:')
       self.id=input('enter id:')
       print(self.name,self.id)

P=Person()
P.PrintData()   


