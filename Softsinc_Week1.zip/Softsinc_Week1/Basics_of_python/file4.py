#reading file and printing it
f=open("file1.py","r")
x=f.read()
print(x)
f.close()

#writing in file 
x="Hi! I am Zunayra Junaid. I am an undergrad at LGU lahore. I am enrolled in computer science department.I have an aim to get into google, meta or microsoft, one of these big companies. I dream big and I will fulfill all of mydrems."
f=open("file4.txt","w")
f.write(x)
f.close()
