import pandas as pd

file_path = "tips.csv"
df = pd.read_csv(file_path)

print(df)
print("\nFirst 5 rows:")
print(df.head())
print("\nDataFrame info:")
print(df.info())
