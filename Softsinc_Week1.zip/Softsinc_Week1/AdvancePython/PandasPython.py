import pandas as pd

data = {
    'Name': ['Alice', 'Bob', 'Andrew', 'Charlie', 'Amanda'],
    'Age': [25, 30, 22, 35, 28]
}

df = pd.DataFrame(data)


filtered_df = df[df['Name'].str.startswith('A')]

print(filtered_df)
