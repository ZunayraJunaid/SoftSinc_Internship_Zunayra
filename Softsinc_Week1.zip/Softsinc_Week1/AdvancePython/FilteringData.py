import pandas as pd

data = {
    'Name': ['Alice', 'Bob', 'Andrew', 'Charlie', 'Amanda'],
    'Age': [25, 30, 22, 35, 28]
}
df = pd.DataFrame(data)

# Filter rows where Age > 25
filtered_df = df[df['Age'] > 25]

print(filtered_df)
